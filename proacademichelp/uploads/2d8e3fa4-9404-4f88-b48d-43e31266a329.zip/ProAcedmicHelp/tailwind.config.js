/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "glow": "radial-gradient(50% 50% at 50% 0%, rgba(59,130,246,0.25) 0%, rgba(59,130,246,0) 70%), radial-gradient(30% 30% at 85% 10%, rgba(16,185,129,0.25) 0%, rgba(16,185,129,0) 70%)",
        "card-gradient": "linear-gradient(180deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%)"
      },
      boxShadow: {
        'soft': '0 10px 30px rgba(0,0,0,0.12)',
      }
    },
  },
  plugins: [],
}
