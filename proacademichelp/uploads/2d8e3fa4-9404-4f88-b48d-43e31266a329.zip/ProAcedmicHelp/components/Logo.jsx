export default function Logo({ className = "" }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#60a5fa" />
            <stop offset="50%" stopColor="#34d399" />
            <stop offset="100%" stopColor="#a78bfa" />
          </linearGradient>
        </defs>
        <rect x="2" y="2" width="20" height="20" rx="5" fill="url(#g)" opacity="0.25" />
        <path d="M6 12h5l2-4 5 8" stroke="url(#g)" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <span className="font-semibold tracking-tight gradient-text">ProAcedmicHelp</span>
    </div>
  );
}
