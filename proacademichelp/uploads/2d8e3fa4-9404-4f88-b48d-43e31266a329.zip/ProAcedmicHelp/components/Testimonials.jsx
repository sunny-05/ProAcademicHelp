'use client'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const testimonials = [
  { name: 'Aisha', text: 'Quick turnaround and excellent quality. My dissertation proposal finally clicked!', course: 'MBA' },
  { name: 'Miguel', text: 'They saved me on a tough deadline. Clear communication, fair price.', course: 'Computer Science' },
  { name: 'Priya', text: 'Proofreading that actually improved my arguments. Highly recommended.', course: 'Sociology' },
]

export default function Testimonials() {
  const [index, setIndex] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % testimonials.length), 4000)
    return () => clearInterval(id)
  }, [])

  const t = testimonials[index]

  return (
    <div className="card p-6 md:p-8">
      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.4 }}
        >
          <p className="text-lg md:text-xl leading-relaxed">“{t.text}”</p>
          <p className="mt-4 text-sm text-white/70">— {t.name}, {t.course}</p>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
