import Image from 'next/image'

const experts = [
  { name: 'Dr. Evelyn Carter', role: 'PhD, Education', img: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?w=400&q=80' },
  { name: 'Liam Chen', role: 'MSc, Data Science', img: 'https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?w=400&q=80' },
  { name: 'Sara Ahmed', role: 'MA, English', img: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?w=400&q=80' },
  { name: 'Marcus Lee', role: 'MBA, Strategy', img: 'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?w=400&q=80' },
]

export default function ExpertsGrid() {
  return (
    <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
      {experts.map((e) => (
        <div key={e.name} className="card p-4">
          <div className="relative w-full h-40 rounded-xl overflow-hidden mb-3">
            <Image src={e.img} alt={e.name} fill className="object-cover" />
          </div>
          <h4 className="font-semibold">{e.name}</h4>
          <p className="text-sm text-white/70">{e.role}</p>
        </div>
      ))}
    </div>
  )
}
