'use client'
import { motion } from 'framer-motion'

export default function ServiceCard({ title, description, href = '#' }) {
  return (
    <motion.a
      href={href}
      target="_self"
      className="card block p-6 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300"
      whileHover={{ scale: 1.02 }}
    >
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-white/70 text-sm leading-relaxed">{description}</p>
    </motion.a>
  )
}
