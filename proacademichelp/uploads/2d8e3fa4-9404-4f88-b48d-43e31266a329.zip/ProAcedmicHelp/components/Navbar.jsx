'use client'
import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, ChevronDown } from 'lucide-react'
import Logo from './Logo'
import CTAButton from './CTAButton'

const dissertations = [
  { label: 'Dissertation Proposal Help', href: '/dissertations/proposal-help' },
  { label: 'Dissertation Proofreading Service', href: '/dissertations/proofreading' },
  { label: 'Dissertation Editing Service', href: '/dissertations/editing' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [openDropdown, setOpenDropdown] = useState(null)

  const NavLink = ({ href, children }) => (
    <Link href={href} className="text-sm hover:text-white/90 transition-colors">{children}</Link>
  )

  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-black/40 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Logo />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6 text-white/80">
          <NavLink href="/">Home</NavLink>

          {/* Services dropdown with a single View all services */}
          <div
            className="relative"
            onMouseEnter={() => setOpenDropdown('services')}
            onMouseLeave={() => setOpenDropdown(null)}
          >
            <button className="inline-flex items-center gap-1 text-sm hover:text-white/90">
              Services <ChevronDown size={16} />
            </button>
            {openDropdown === 'services' && (
              <div className="absolute left-0 mt-3 w-56 p-2 card">
                <Link href="/services" className="block px-3 py-2 rounded-lg hover:bg-white/5">
                  View all services
                </Link>
              </div>
            )}
          </div>

          {/* Dissertations dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setOpenDropdown('dissertations')}
            onMouseLeave={() => setOpenDropdown(null)}
          >
            <button className="inline-flex items-center gap-1 text-sm hover:text-white/90">
              Dissertations <ChevronDown size={16} />
            </button>
            {openDropdown === 'dissertations' && (
              <div className="absolute left-0 mt-3 w-80 p-2 card">
                {dissertations.map((d) => (
                  <Link key={d.href} href={d.href} className="block px-3 py-2 rounded-lg hover:bg-white/5">
                    {d.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <NavLink href="/homework">Homework</NavLink>
          <NavLink href="/answers">Answers</NavLink>
          <NavLink href="/blogs">Blogs</NavLink>
          <NavLink href="/experts">Experts</NavLink>
          <NavLink href="/reviews">Reviews</NavLink>

          <CTAButton />
        </nav>

        {/* Mobile button */}
        <button className="md:hidden text-white" onClick={() => setOpen(v => !v)} aria-label="Toggle menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden border-t border-white/10 bg-black/70">
          <div className="px-4 py-3 space-y-2">
            <Link href="/" className="block py-2">Home</Link>
            <details className="group">
              <summary className="flex items-center justify-between py-2 cursor-pointer">
                <span>Services</span>
                <ChevronDown className="group-open:rotate-180 transition" size={16} />
              </summary>
              <div className="pl-3 text-white/80">
                <Link href="/services" className="block py-2">View all services</Link>
              </div>
            </details>

            <details className="group">
              <summary className="flex items-center justify-between py-2 cursor-pointer">
                <span>Dissertations</span>
                <ChevronDown className="group-open:rotate-180 transition" size={16} />
              </summary>
              <div className="pl-3 text-white/80 space-y-1">
                {dissertations.map((d) => (
                  <Link key={d.href} href={d.href} className="block py-2">{d.label}</Link>
                ))}
              </div>
            </details>

            <Link href="/homework" className="block py-2">Homework</Link>
            <Link href="/answers" className="block py-2">Answers</Link>
            <Link href="/blogs" className="block py-2">Blogs</Link>
            <Link href="/experts" className="block py-2">Experts</Link>
            <Link href="/reviews" className="block py-2">Reviews</Link>

            <div className="pt-2"><CTAButton /></div>
          </div>
        </div>
      )}
    </header>
  )
}
