export default function BlogList() {
  const posts = [
    { title: 'How to structure a winning dissertation', href: '#', date: 'Aug 2025' },
    { title: 'Proofreading checklist for busy students', href: '#', date: 'Aug 2025' },
    { title: 'Top tips to beat procrastination', href: '#', date: 'Jul 2025' },
  ]
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {posts.map((p) => (
        <a key={p.title} href={p.href} className="card p-5 hover:shadow-xl transition">
          <h4 className="font-semibold mb-2">{p.title}</h4>
          <p className="text-xs text-white/60">{p.date}</p>
        </a>
      ))}
    </div>
  )
}
