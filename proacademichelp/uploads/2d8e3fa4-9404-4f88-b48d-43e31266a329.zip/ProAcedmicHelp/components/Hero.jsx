'use client'
import { motion } from 'framer-motion'
import CTAButton from './CTAButton'
import Marquee from './Marquee'

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 bg-glow" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-10">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-4xl md:text-6xl font-extrabold tracking-tight text-center leading-tight"
        >
          Get <span className="gradient-text">expert academic help</span>, <br className="hidden md:block" />
          delivered fast and stress‑free.
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="mt-6 text-center text-white/80 max-w-2xl mx-auto"
        >
          Essays, dissertations, homework, and more—our vetted experts handle it all with quality, confidentiality, and on‑time delivery.
        </motion.p>

        <div className="mt-8 flex justify-center">
          <CTAButton>Request a Free Quote</CTAButton>
        </div>

        <div className="mt-10">
          <Marquee items={[
            'Essay Writing', 'Dissertation Proposal', 'Proofreading', 'Editing',
            'Homework Help', 'Lab Reports', 'Case Studies', 'Presentations'
          ]} />
        </div>
      </div>
    </section>
  )
}
