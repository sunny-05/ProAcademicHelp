'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'

export default function CTAButton({ href = '/request-quote', children = 'Request a Quote' }) {
  return (
    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
      <Link
        href={href}
        className="inline-flex items-center gap-2 rounded-xl px-5 py-3 bg-gradient-to-r from-blue-500 to-emerald-500 text-white font-medium shadow-soft"
      >
        {children}
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      </Link>
    </motion.div>
  )
}
