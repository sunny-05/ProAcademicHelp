export default function Marquee({ items = [] }) {
  const track = [...items, ...items] // duplicate for seamless loop
  return (
    <div className="marquee py-3">
      <div className="marquee__track">
        {track.map((t, i) => (
          <span key={i} className="text-sm text-white/70">{t}</span>
        ))}
      </div>
    </div>
  )
}
