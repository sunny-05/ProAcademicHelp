import CTAButton from '@/components/CTAButton'

export const metadata = { title: 'Dissertation Proposal Help — ProAcedmicHelp' }

export default function Page() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-4">Dissertation Proposal Help</h1>
      <p className="text-white/80 max-w-3xl">
        We help you narrow your topic, articulate strong research questions, and select suitable methodology and data collection plans.
        You’ll receive a structured outline, literature mapping, and a realistic timeline.
      </p>
      <ul className="mt-6 space-y-2 text-white/80">
        <li>• Topic refinement & scope</li>
        <li>• Objectives, questions, and hypotheses</li>
        <li>• Methodology & ethics</li>
        <li>• Timeline & feasibility</li>
      </ul>
      <div className="mt-6"><CTAButton /></div>
    </section>
  )
}
