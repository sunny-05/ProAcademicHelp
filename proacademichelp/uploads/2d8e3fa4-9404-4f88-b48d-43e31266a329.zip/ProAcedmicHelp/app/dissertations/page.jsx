import Link from 'next/link'

export const metadata = { title: 'Dissertations — ProAcedmicHelp' }

const items = [
  { label: 'Dissertation Proposal Help', href: '/dissertations/proposal-help' },
  { label: 'Dissertation Proofreading Service', href: '/dissertations/proofreading' },
  { label: 'Dissertation Editing Service', href: '/dissertations/editing' },
]

export default function DissertationsIndex() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-6">Dissertation Services</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {items.map(i => (
          <Link key={i.href} href={i.href} className="card p-6 hover:shadow-xl transition">
            <h3 className="font-semibold">{i.label}</h3>
            <p className="text-sm text-white/70 mt-2">Click to learn more & request a quote.</p>
          </Link>
        ))}
      </div>
    </section>
  )
}
