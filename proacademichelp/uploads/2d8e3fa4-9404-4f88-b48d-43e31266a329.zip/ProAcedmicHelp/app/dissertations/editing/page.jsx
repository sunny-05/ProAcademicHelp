import CTAButton from '@/components/CTAButton'

export const metadata = { title: 'Dissertation Editing Service — ProAcedmicHelp' }

export default function Page() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-4">Dissertation Editing Service</h1>
      <p className="text-white/80 max-w-3xl">
        Structural improvements: argument flow, coherence, section ordering, and strengthening evidence, plus formatting per your style guide.
      </p>
      <ul className="mt-6 space-y-2 text-white/80">
        <li>• Structure & flow</li>
        <li>• Evidence and citations</li>
        <li>• Figures & tables checks</li>
        <li>• Formatting to guidelines</li>
      </ul>
      <div className="mt-6"><CTAButton /></div>
    </section>
  )
}
