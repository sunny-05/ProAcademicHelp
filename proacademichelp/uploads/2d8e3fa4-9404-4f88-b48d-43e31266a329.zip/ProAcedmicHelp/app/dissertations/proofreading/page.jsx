import CTAButton from '@/components/CTAButton'

export const metadata = { title: 'Dissertation Proofreading Service — ProAcedmicHelp' }

export default function Page() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-4">Dissertation Proofreading Service</h1>
      <p className="text-white/80 max-w-3xl">
        Line‑by‑line corrections to spelling, grammar, punctuation, and style, while preserving your academic voice.
      </p>
      <ul className="mt-6 space-y-2 text-white/80">
        <li>• Grammar & clarity</li>
        <li>• Consistent academic tone</li>
        <li>• Reference formatting</li>
        <li>• Plagiarism‑safe guidance</li>
      </ul>
      <div className="mt-6"><CTAButton /></div>
    </section>
  )
}
