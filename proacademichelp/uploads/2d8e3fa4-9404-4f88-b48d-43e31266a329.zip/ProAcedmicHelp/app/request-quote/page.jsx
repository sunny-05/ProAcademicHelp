'use client'
import { useState } from 'react'

export const metadata = { title: 'Request a Quote — ProAcedmicHelp' }

export default function RequestQuotePage() {
  const [status, setStatus] = useState(null)

  async function onSubmit(e) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    const payload = Object.fromEntries(form.entries())

    // basic honeypot check
    if (payload.middle_name) return

    setStatus('submitting')
    try {
      const res = await fetch('/api/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      const data = await res.json()
      if (res.ok) setStatus('success')
      else setStatus(data?.error || 'error')
    } catch (e) {
      setStatus('error')
    }
  }

  return (
    <section className="py-10 max-w-2xl">
      <h1 className="text-3xl font-bold mb-4">Request a Free Quote</h1>
      <p className="text-white/80 mb-6">Tell us about your task. We’ll reply with a clear quote and timeline.</p>

      <form onSubmit={onSubmit} className="card p-6 space-y-4">
        <input type="text" name="middle_name" className="hidden" tabIndex={-1} autoComplete="off" />
        <div>
          <label className="block text-sm mb-1">Full name</label>
          <input name="name" required className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm mb-1">Email</label>
          <input name="email" type="email" required className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm mb-1">Service</label>
            <select name="service" className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2">
              <option>Dissertation Proposal</option>
              <option>Proofreading</option>
              <option>Editing</option>
              <option>Homework Help</option>
              <option>Other</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1">Deadline</label>
            <input name="deadline" type="date" className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="block text-sm mb-1">Brief</label>
          <textarea name="brief" rows="5" placeholder="Describe the task, word count, referencing style, etc." className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2"></textarea>
        </div>

        <button
          type="submit"
          disabled={status === 'submitting'}
          className="rounded-xl px-5 py-3 bg-gradient-to-r from-blue-500 to-emerald-500 text-white font-medium shadow-soft"
        >
          {status === 'submitting' ? 'Sending…' : 'Submit request'}
        </button>

        {status === 'success' && <p className="text-emerald-400">Thanks! We received your request.</p>}
        {status && status !== 'success' && status !== 'submitting' && <p className="text-red-400">Something went wrong. Please try again.</p>}
      </form>
    </section>
  )
}
