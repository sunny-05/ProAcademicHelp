import ServiceCard from '@/components/ServiceCard'

export const metadata = { title: 'Services — ProAcedmicHelp' }

const services = [
  { title: 'Dissertation Proposal Help', href: '/dissertations/proposal-help', description: 'Solidify your topic, research questions, and methods with expert guidance.' },
  { title: 'Dissertation Proofreading Service', href: '/dissertations/proofreading', description: 'Eliminate errors, sharpen clarity, and elevate academic tone.' },
  { title: 'Dissertation Editing Service', href: '/dissertations/editing', description: 'Structural edits, argument flow, referencing checks, and formatting.' },
  { title: 'Homework Help', href: '/homework', description: 'Step‑by‑step guidance across STEM, business, humanities, and more.' },
  { title: 'Answers', href: '/answers', description: 'Concise, well‑explained answers to specific academic questions.' },
  { title: 'Blog Writing & Optimization', href: '/blogs', description: 'SEO‑friendly blog posts with credible academic tone and references.' },
  { title: 'Expert Consultations', href: '/experts', description: 'Book a session with a subject‑matter specialist.' },
]

export default function ServicesPage() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-6">All services</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {services.map(s => <ServiceCard key={s.title} {...s} />)}
      </div>
    </section>
  )
}
