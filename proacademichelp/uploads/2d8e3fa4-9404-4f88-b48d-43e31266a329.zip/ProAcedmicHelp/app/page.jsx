import Hero from '@/components/Hero'
import AnimatedSection from '@/components/AnimatedSection'
import ServiceCard from '@/components/ServiceCard'
import Testimonials from '@/components/Testimonials'
import ExpertsGrid from '@/components/ExpertsGrid'
import BlogList from '@/components/BlogList'
import CTAButton from '@/components/CTAButton'

export default function HomePage() {
  return (
    <>
      <Hero />

      <AnimatedSection>
        <section id="services" className="mt-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">Popular services</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <ServiceCard title="Dissertation Proposal Help" description="Craft a sharp, feasible research proposal with clear aims, methodology, and timeline." href="/dissertations/proposal-help" />
            <ServiceCard title="Proofreading Service" description="Polish your writing—grammar, clarity, flow, and academic tone—by expert editors." href="/dissertations/proofreading" />
            <ServiceCard title="Homework Help" description="From math to marketing, get guided solutions and explanations tailored to you." href="/homework" />
          </div>
          <div className="mt-6"><CTAButton href="/services">View all services</CTAButton></div>
        </section>
      </AnimatedSection>

      <AnimatedSection delay={0.1}>
        <section className="mt-16 grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-xl md:text-2xl font-bold mb-4">Why students choose us</h3>
            <ul className="space-y-2 text-white/80">
              <li>• Subject‑matter experts (Masters & PhDs)</li>
              <li>• 100% confidentiality & original work</li>
              <li>• Transparent pricing & milestones</li>
              <li>• On‑time delivery, every time</li>
            </ul>
            <div className="mt-6"><CTAButton /></div>
          </div>
          <Testimonials />
        </section>
      </AnimatedSection>

      <AnimatedSection delay={0.2}>
        <section id="experts" className="mt-16">
          <h3 className="text-xl md:text-2xl font-bold mb-4">Meet a few experts</h3>
          <ExpertsGrid />
        </section>
      </AnimatedSection>

      <AnimatedSection delay={0.3}>
        <section id="blogs" className="mt-16">
          <h3 className="text-xl md:text-2xl font-bold mb-4">From the blog</h3>
          <BlogList />
        </section>
      </AnimatedSection>

      <AnimatedSection delay={0.35}>
        <section className="my-16 text-center card p-8">
          <h3 className="text-2xl font-bold mb-3">Ready to get started?</h3>
          <p className="text-white/80 mb-6">Tell us about your task and we’ll send a free, no‑obligation quote.</p>
          <CTAButton />
        </section>
      </AnimatedSection>
    </>
  )
}
