import CTAButton from '@/components/CTAButton'

export const metadata = { title: 'Experts — ProAcedmicHelp' }

export default function Page() {
  return (
    <section className="py-10">
      <h1 className="text-3xl font-bold mb-4">Experts</h1>
      <p className="text-white/80 max-w-3xl">
        This is the experts page. Add your content here (listings, filters, articles, etc.).
      </p>
      <div className="mt-6"><CTAButton /></div>
    </section>
  )
}
