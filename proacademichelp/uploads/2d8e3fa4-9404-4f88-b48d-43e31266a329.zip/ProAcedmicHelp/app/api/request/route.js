export async function POST(req) {
  try {
    const data = await req.json()

    // Basic validation
    if (!data?.email || !data?.name) {
      return new Response(JSON.stringify({ error: 'Name and email are required.' }), { status: 400 })
    }

    // In production: integrate your email provider here (Nodemailer/Resend/etc).
    // For now, we log the submission.
    console.log('New request:', data)

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Invalid request' }), { status: 400 })
  }
}
