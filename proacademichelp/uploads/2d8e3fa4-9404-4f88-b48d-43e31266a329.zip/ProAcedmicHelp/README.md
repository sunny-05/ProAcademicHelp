# ProAcedmicHelp — Next.js App Router (JSX) + Tailwind + Framer Motion

A modern, animated marketing site to capture client requests for ProAcedmicHelp.

## Quickstart

```bash
npm install
npm run dev
# open http://localhost:3000
```

## Tech
- Next.js 14 (App Router, JSX)
- Tailwind CSS
- Framer Motion for animations
- Minimal API route at `/api/request` for quote submissions (logs to server)

## Project Structure

```
app/
  layout.jsx            # Root layout and global shell
  page.jsx              # Home page with hero, services, testimonials, blog preview
  globals.css           # Tailwind and global styles
  services/page.jsx     # "View all services"
  dissertations/
    page.jsx
    proposal-help/page.jsx
    proofreading/page.jsx
    editing/page.jsx
  homework/page.jsx
  answers/page.jsx
  blogs/page.jsx
  experts/page.jsx
  reviews/page.jsx
  request-quote/page.jsx# Form to capture leads
  api/request/route.js  # POST endpoint for requests (logs)
components/
  Navbar.jsx            # Responsive navbar with dropdowns
  Footer.jsx
  Hero.jsx              # Animated hero + marquee
  AnimatedSection.jsx   # Fade-up on scroll
  ServiceCard.jsx
  Testimonials.jsx      # Auto-rotating card
  ExpertsGrid.jsx
  BlogList.jsx
  CTAButton.jsx
  Logo.jsx
tailwind.config.js
postcss.config.js
next.config.js
package.json
README.md
```

### Customization
- Update branding in `Logo.jsx`, colors in `tailwind.config.js`, and copy across pages.
- Hook up real emails: replace the logic in `app/api/request/route.js` with your email provider (Nodemailer/SMTP, Resend, SendGrid, etc.).
- SEO: edit `metadata` exports in pages or `app/layout.jsx`.

### Deploy
- Vercel or any Node host:
  - Add env vars for your email integration if used.
  - `npm run build` then deploy.
```

